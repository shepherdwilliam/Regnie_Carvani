﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Welcome : MonoBehaviour {

	/*
	 * Welcome to REGNIE CARVANI!
	 * Hitsujikai-P (twitter:@hitsujikaip)
	 * ------------------------------------------------
	 * Copyright 2017 Hitsujikai-P All Rights Reserved. 
	 * 
	 */

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
